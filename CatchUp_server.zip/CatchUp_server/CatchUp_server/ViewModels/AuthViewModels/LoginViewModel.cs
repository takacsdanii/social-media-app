﻿namespace CatchUp_server.ViewModels.AuthViewModels
{
    public class LoginViewModel
    {
        public string UserNameOrEmail { get; set; }
        public string Password { get; set; }
    }
}
