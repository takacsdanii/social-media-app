﻿namespace CatchUp_server.ViewModels.AuthViewModels
{
    public class ResetPasswordViewModel
    {
        public string Email { get; set; }
        public string ResetToken { get; set; }
    }
}
