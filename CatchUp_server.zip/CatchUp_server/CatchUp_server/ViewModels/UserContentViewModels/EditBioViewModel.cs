﻿namespace CatchUp_server.ViewModels.UserContentViewModels
{
    public class EditBioViewModel
    {
        public string userId { get; set; }
        public string? Bio { get; set; }
    }
}
