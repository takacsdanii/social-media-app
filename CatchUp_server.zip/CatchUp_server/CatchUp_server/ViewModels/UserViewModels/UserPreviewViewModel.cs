﻿namespace CatchUp_server.ViewModels.UserViewModels
{
    public class UserPreviewViewModel
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string ProfilePicUrl { get; set; }
    }
}
