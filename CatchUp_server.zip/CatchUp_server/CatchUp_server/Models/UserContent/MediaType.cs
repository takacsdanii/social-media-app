﻿namespace CatchUp_server.Models.UserContent
{
    public enum MediaType
    {
        Image = 0,
        Video = 1,
        Other = 2
    }
}
