export class UserPreviewModel {
    public id: string;
    public userName: string;
    public profilePicUrl: string | null;
}