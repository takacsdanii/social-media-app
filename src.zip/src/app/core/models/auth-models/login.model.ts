export class LoginModel {
    public userNameOrEmail: string;
    public password: string;
}