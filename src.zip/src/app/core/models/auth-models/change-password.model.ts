export class ChangePasswordModel {
    public id: string;
    public oldPassword: string;
    public newPassword: string;
    public confirmNewPassword: string;
}