export class ResetPasswordModel {
    public email: string;
    public resetToken: string;
}