export class LikeModel {
    public id: number;
    public likedAt: Date;
    public userId: string;
    public userName: string;
    public profilePicUrl: string;
}