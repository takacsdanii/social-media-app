export class SearchUserModel {
    public id: string;
    public userName: string;
    public profilePicUrl: string;
    public firstName: string;
    public lastName: string;
}