export enum MediaTypeModel {
    Image = 0,
    Video = 1,
    Other = 2
}