export enum GenderModel {
    Female = 0,
    Male = 1,
    Other = 2
}