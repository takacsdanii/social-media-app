export enum VisibilityModel {
    Public = 0,
    Friends = 1,
    Followers = 2,
    Following = 3,
    Private = 4,
    Custom = 5
}